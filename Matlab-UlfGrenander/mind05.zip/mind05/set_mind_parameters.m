function set_mind_parameters
%recomputes "Q" and "A"
sqrt(2)