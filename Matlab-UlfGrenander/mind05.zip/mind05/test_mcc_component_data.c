/*
 * MATLAB Compiler: 4.1 (R14SP1)
 * Date: Mon Feb 21 17:58:19 2005
 * Arguments: "-B" "macro_default" "-m" "-W" "main" "-T" "link:exe" "test" 
 */


#ifdef __cplusplus
extern "C" {
#endif
const unsigned char __MCC_test_public_data[] = {'3', '0', '8', '1', '9', 'D',
                                                '3', '0', '0', 'D', '0', '6',
                                                '0', '9', '2', 'A', '8', '6',
                                                '4', '8', '8', '6', 'F', '7',
                                                '0', 'D', '0', '1', '0', '1',
                                                '0', '1', '0', '5', '0', '0',
                                                '0', '3', '8', '1', '8', 'B',
                                                '0', '0', '3', '0', '8', '1',
                                                '8', '7', '0', '2', '8', '1',
                                                '8', '1', '0', '0', 'C', '4',
                                                '9', 'C', 'A', 'C', '3', '4',
                                                'E', 'D', '1', '3', 'A', '5',
                                                '2', '0', '6', '5', '8', 'F',
                                                '6', 'F', '8', 'E', '0', '1',
                                                '3', '8', 'C', '4', '3', '1',
                                                '5', 'B', '4', '3', '1', '5',
                                                '2', '7', '7', 'E', 'D', '3',
                                                'F', '7', 'D', 'A', 'E', '5',
                                                '3', '0', '9', '9', 'D', 'B',
                                                '0', '8', 'E', 'E', '5', '8',
                                                '9', 'F', '8', '0', '4', 'D',
                                                '4', 'B', '9', '8', '1', '3',
                                                '2', '6', 'A', '5', '2', 'C',
                                                'C', 'E', '4', '3', '8', '2',
                                                'E', '9', 'F', '2', 'B', '4',
                                                'D', '0', '8', '5', 'E', 'B',
                                                '9', '5', '0', 'C', '7', 'A',
                                                'B', '1', '2', 'E', 'D', 'E',
                                                '2', 'D', '4', '1', '2', '9',
                                                '7', '8', '2', '0', 'E', '6',
                                                '3', '7', '7', 'A', '5', 'F',
                                                'E', 'B', '5', '6', '8', '9',
                                                'D', '4', 'E', '6', '0', '3',
                                                '2', 'F', '6', '0', 'C', '4',
                                                '3', '0', '7', '4', 'A', '0',
                                                '4', 'C', '2', '6', 'A', 'B',
                                                '7', '2', 'F', '5', '4', 'B',
                                                '5', '1', 'B', 'B', '4', '6',
                                                '0', '5', '7', '8', '7', '8',
                                                '5', 'B', '1', '9', '9', '0',
                                                '1', '4', '3', '1', '4', 'A',
                                                '6', '5', 'F', '0', '9', '0',
                                                'B', '6', '1', 'F', 'C', '2',
                                                '0', '1', '6', '9', '4', '5',
                                                '3', 'B', '5', '8', 'F', 'C',
                                                '8', 'B', 'A', '4', '3', 'E',
                                                '6', '7', '7', '6', 'E', 'B',
                                                '7', 'E', 'C', 'D', '3', '1',
                                                '7', '8', 'B', '5', '6', 'A',
                                                'B', '0', 'F', 'A', '0', '6',
                                                'D', 'D', '6', '4', '9', '6',
                                                '7', 'C', 'B', '1', '4', '9',
                                                'E', '5', '0', '2', '0', '1',
                                                '1', '1', '\0'};

const char *__MCC_test_name_data = "test";

const char *__MCC_test_root_data = "";

const unsigned char __MCC_test_session_data[] = {'1', '7', 'D', 'D', 'D', '4',
                                                 '3', 'A', '0', 'B', '7', '1',
                                                 '2', '8', 'D', 'B', '7', '3',
                                                 'C', '2', '0', 'C', '0', '4',
                                                 '1', '3', 'D', '8', '3', 'A',
                                                 '8', 'A', 'D', 'B', '2', '8',
                                                 '1', 'D', 'F', '5', '3', 'D',
                                                 'E', 'A', 'B', '0', '9', '7',
                                                 'D', '5', '1', 'C', '4', 'E',
                                                 '7', 'B', 'F', '8', '7', '8',
                                                 'B', 'C', '5', 'E', 'D', 'D',
                                                 'C', '3', '6', '9', '6', '4',
                                                 '9', 'C', 'A', 'A', '3', 'B',
                                                 '1', 'F', 'A', 'D', '8', '2',
                                                 '7', '3', '6', '4', 'D', '4',
                                                 'E', '8', '8', '8', '0', 'A',
                                                 '7', '4', 'C', '8', '9', '1',
                                                 'C', '9', '0', '8', '9', '2',
                                                 'D', 'D', 'A', '0', 'E', '0',
                                                 '2', '2', '3', '1', '6', '1',
                                                 '0', '2', '5', '5', '3', '5',
                                                 'E', '5', 'F', '3', 'E', '1',
                                                 '6', '2', '2', '3', '1', 'B',
                                                 'D', '2', 'B', '5', '9', 'B',
                                                 '4', 'C', '4', '6', 'E', 'E',
                                                 '3', 'A', '9', '3', 'C', '8',
                                                 '4', 'A', '6', 'D', 'D', 'B',
                                                 'D', '0', 'C', 'D', '2', '2',
                                                 '8', '5', '6', '9', '3', 'C',
                                                 '8', '5', '8', 'A', '2', 'A',
                                                 '1', '5', '3', 'E', '4', 'C',
                                                 '0', 'C', '9', '1', '4', 'A',
                                                 '2', '8', 'C', 'A', '6', '3',
                                                 '7', '2', 'F', 'D', 'F', 'A',
                                                 'A', '0', 'D', '8', '9', 'A',
                                                 '0', '5', 'A', '2', '9', 'D',
                                                 '8', '4', '6', '8', '9', 'B',
                                                 '2', 'D', 'C', '3', '4', '6',
                                                 '9', 'C', '3', '8', '9', 'E',
                                                 '5', '7', 'B', 'D', '7', 'F',
                                                 'D', '2', '2', 'E', '5', 'E',
                                                 'A', '3', 'C', '5', '5', '4',
                                                 'E', '6', '6', 'E', '\0'};

const char *__MCC_test_matlabpath_data[] = {"test/",
                                            "toolbox/compiler/deploy/",
                                            "$TOOLBOXMATLABDIR/general/",
                                            "$TOOLBOXMATLABDIR/ops/",
                                            "$TOOLBOXMATLABDIR/lang/",
                                            "$TOOLBOXMATLABDIR/elmat/",
                                            "$TOOLBOXMATLABDIR/elfun/",
                                            "$TOOLBOXMATLABDIR/specfun/",
                                            "$TOOLBOXMATLABDIR/matfun/",
                                            "$TOOLBOXMATLABDIR/datafun/",
                                            "$TOOLBOXMATLABDIR/polyfun/",
                                            "$TOOLBOXMATLABDIR/funfun/",
                                            "$TOOLBOXMATLABDIR/sparfun/",
                                            "$TOOLBOXMATLABDIR/scribe/",
                                            "$TOOLBOXMATLABDIR/graph2d/",
                                            "$TOOLBOXMATLABDIR/graph3d/",
                                            "$TOOLBOXMATLABDIR/specgraph/",
                                            "$TOOLBOXMATLABDIR/graphics/",
                                            "$TOOLBOXMATLABDIR/uitools/",
                                            "$TOOLBOXMATLABDIR/strfun/",
                                            "$TOOLBOXMATLABDIR/imagesci/",
                                            "$TOOLBOXMATLABDIR/iofun/",
                                            "$TOOLBOXMATLABDIR/audiovideo/",
                                            "$TOOLBOXMATLABDIR/timefun/",
                                            "$TOOLBOXMATLABDIR/datatypes/",
                                            "$TOOLBOXMATLABDIR/verctrl/",
                                            "$TOOLBOXMATLABDIR/codetools/",
                                            "$TOOLBOXMATLABDIR/helptools/",
                                            "$TOOLBOXMATLABDIR/winfun/",
                                            "$TOOLBOXMATLABDIR/demos/",
                                            "toolbox/local/",
                                            "toolbox/compiler/"};
const int __MCC_test_matlabpath_data_count = 32;

const char *__MCC_test_classpath_data[] = { "" };
const int __MCC_test_classpath_data_count = 0;

const char *__MCC_test_mcr_application_options[] = { "" };
const int __MCC_test_mcr_application_option_count = 0;
const char *__MCC_test_mcr_runtime_options[] = { "" };
const int __MCC_test_mcr_runtime_option_count = 0;
#ifdef __cplusplus
}
#endif


