/*
 * MATLAB Compiler: 4.1 (R14SP1)
 * Date: Thu Mar 03 10:41:48 2005
 * Arguments: "-B" "macro_default" "-m" "-W" "main" "-T" "link:exe" "think.m"
 * "-a" "c:\mind_data.mat" 
 */


#ifdef __cplusplus
extern "C" {
#endif
const unsigned char __MCC_think_public_data[] = {'3', '0', '8', '1', '9', 'D',
                                                 '3', '0', '0', 'D', '0', '6',
                                                 '0', '9', '2', 'A', '8', '6',
                                                 '4', '8', '8', '6', 'F', '7',
                                                 '0', 'D', '0', '1', '0', '1',
                                                 '0', '1', '0', '5', '0', '0',
                                                 '0', '3', '8', '1', '8', 'B',
                                                 '0', '0', '3', '0', '8', '1',
                                                 '8', '7', '0', '2', '8', '1',
                                                 '8', '1', '0', '0', 'C', '4',
                                                 '9', 'C', 'A', 'C', '3', '4',
                                                 'E', 'D', '1', '3', 'A', '5',
                                                 '2', '0', '6', '5', '8', 'F',
                                                 '6', 'F', '8', 'E', '0', '1',
                                                 '3', '8', 'C', '4', '3', '1',
                                                 '5', 'B', '4', '3', '1', '5',
                                                 '2', '7', '7', 'E', 'D', '3',
                                                 'F', '7', 'D', 'A', 'E', '5',
                                                 '3', '0', '9', '9', 'D', 'B',
                                                 '0', '8', 'E', 'E', '5', '8',
                                                 '9', 'F', '8', '0', '4', 'D',
                                                 '4', 'B', '9', '8', '1', '3',
                                                 '2', '6', 'A', '5', '2', 'C',
                                                 'C', 'E', '4', '3', '8', '2',
                                                 'E', '9', 'F', '2', 'B', '4',
                                                 'D', '0', '8', '5', 'E', 'B',
                                                 '9', '5', '0', 'C', '7', 'A',
                                                 'B', '1', '2', 'E', 'D', 'E',
                                                 '2', 'D', '4', '1', '2', '9',
                                                 '7', '8', '2', '0', 'E', '6',
                                                 '3', '7', '7', 'A', '5', 'F',
                                                 'E', 'B', '5', '6', '8', '9',
                                                 'D', '4', 'E', '6', '0', '3',
                                                 '2', 'F', '6', '0', 'C', '4',
                                                 '3', '0', '7', '4', 'A', '0',
                                                 '4', 'C', '2', '6', 'A', 'B',
                                                 '7', '2', 'F', '5', '4', 'B',
                                                 '5', '1', 'B', 'B', '4', '6',
                                                 '0', '5', '7', '8', '7', '8',
                                                 '5', 'B', '1', '9', '9', '0',
                                                 '1', '4', '3', '1', '4', 'A',
                                                 '6', '5', 'F', '0', '9', '0',
                                                 'B', '6', '1', 'F', 'C', '2',
                                                 '0', '1', '6', '9', '4', '5',
                                                 '3', 'B', '5', '8', 'F', 'C',
                                                 '8', 'B', 'A', '4', '3', 'E',
                                                 '6', '7', '7', '6', 'E', 'B',
                                                 '7', 'E', 'C', 'D', '3', '1',
                                                 '7', '8', 'B', '5', '6', 'A',
                                                 'B', '0', 'F', 'A', '0', '6',
                                                 'D', 'D', '6', '4', '9', '6',
                                                 '7', 'C', 'B', '1', '4', '9',
                                                 'E', '5', '0', '2', '0', '1',
                                                 '1', '1', '\0'};

const char *__MCC_think_name_data = "think";

const char *__MCC_think_root_data = "";

const unsigned char __MCC_think_session_data[] = {'6', 'E', '1', '9', '8',
                                                  '1', 'A', '2', '1', '1',
                                                  '9', 'D', 'D', '7', '5',
                                                  '7', 'E', '2', '7', 'E',
                                                  '6', '2', '2', '4', 'A',
                                                  '5', '9', '8', 'A', '4',
                                                  '7', '6', 'C', '2', 'C',
                                                  '2', 'D', '0', '1', 'D',
                                                  'B', '2', 'C', 'A', '3',
                                                  'B', '4', '0', '7', '2',
                                                  'D', '0', '9', '4', 'E',
                                                  '3', '8', 'D', '6', 'F',
                                                  '2', 'B', 'A', '2', '3',
                                                  '4', '3', 'A', '0', '6',
                                                  '5', '0', '4', '0', '9',
                                                  'F', '4', '2', '7', 'D',
                                                  '0', 'A', 'D', '5', 'F',
                                                  '1', '2', '2', '3', '8',
                                                  '5', '9', 'E', 'E', 'B',
                                                  'A', 'A', 'C', '2', 'D',
                                                  '5', '1', '3', '5', '4',
                                                  '6', '1', 'E', 'B', '8',
                                                  'E', '0', '6', 'B', '3',
                                                  'A', 'C', 'C', 'D', 'D',
                                                  '4', 'C', '2', '1', '0',
                                                  '8', 'B', '6', '8', '4',
                                                  '3', 'F', 'A', '7', 'F',
                                                  '8', 'F', '2', '8', '2',
                                                  '3', 'F', 'B', '6', 'C',
                                                  'F', 'D', '1', 'E', '4',
                                                  '4', 'A', '1', '9', '5',
                                                  '5', 'E', 'D', '2', '5',
                                                  '5', '9', '3', '0', '2',
                                                  '5', 'E', '8', '3', '0',
                                                  '9', '6', 'E', '0', 'F',
                                                  '3', 'D', '4', 'F', '9',
                                                  'F', '2', '2', 'B', 'C',
                                                  'B', '5', '9', 'B', 'C',
                                                  '0', '2', '7', '1', '4',
                                                  '5', 'E', '4', 'A', '4',
                                                  'B', '5', 'A', 'E', 'D',
                                                  'D', 'B', '9', 'C', '1',
                                                  'C', '2', 'C', '6', '3',
                                                  '7', '1', 'A', 'A', 'C',
                                                  '1', '3', '5', 'C', 'E',
                                                  '6', '3', 'C', 'F', '1',
                                                  'E', '2', '3', '8', '1',
                                                  '3', '8', '2', '6', '2',
                                                  'C', '2', 'F', 'E', 'A',
                                                  'C', 'B', '7', 'F', 'C',
                                                  '4', 'C', 'C', '6', 'C',
                                                  'F', '\0'};

const char *__MCC_think_matlabpath_data[] = {"think/",
                                             "toolbox/compiler/deploy/",
                                             "$TOOLBOXMATLABDIR/general/",
                                             "$TOOLBOXMATLABDIR/ops/",
                                             "$TOOLBOXMATLABDIR/lang/",
                                             "$TOOLBOXMATLABDIR/elmat/",
                                             "$TOOLBOXMATLABDIR/elfun/",
                                             "$TOOLBOXMATLABDIR/specfun/",
                                             "$TOOLBOXMATLABDIR/matfun/",
                                             "$TOOLBOXMATLABDIR/datafun/",
                                             "$TOOLBOXMATLABDIR/polyfun/",
                                             "$TOOLBOXMATLABDIR/funfun/",
                                             "$TOOLBOXMATLABDIR/sparfun/",
                                             "$TOOLBOXMATLABDIR/scribe/",
                                             "$TOOLBOXMATLABDIR/graph2d/",
                                             "$TOOLBOXMATLABDIR/graph3d/",
                                             "$TOOLBOXMATLABDIR/specgraph/",
                                             "$TOOLBOXMATLABDIR/graphics/",
                                             "$TOOLBOXMATLABDIR/uitools/",
                                             "$TOOLBOXMATLABDIR/strfun/",
                                             "$TOOLBOXMATLABDIR/imagesci/",
                                             "$TOOLBOXMATLABDIR/iofun/",
                                             "$TOOLBOXMATLABDIR/audiovideo/",
                                             "$TOOLBOXMATLABDIR/timefun/",
                                             "$TOOLBOXMATLABDIR/datatypes/",
                                             "$TOOLBOXMATLABDIR/verctrl/",
                                             "$TOOLBOXMATLABDIR/codetools/",
                                             "$TOOLBOXMATLABDIR/helptools/",
                                             "$TOOLBOXMATLABDIR/winfun/",
                                             "$TOOLBOXMATLABDIR/demos/",
                                             "toolbox/local/",
                                             "toolbox/compiler/"};
const int __MCC_think_matlabpath_data_count = 32;

const char *__MCC_think_classpath_data[] = { "" };
const int __MCC_think_classpath_data_count = 0;

const char *__MCC_think_mcr_application_options[] = { "" };
const int __MCC_think_mcr_application_option_count = 0;
const char *__MCC_think_mcr_runtime_options[] = { "" };
const int __MCC_think_mcr_runtime_option_count = 0;
#ifdef __cplusplus
}
#endif


