function val2=m2(val2)
load c:\new val1
save c:\new 