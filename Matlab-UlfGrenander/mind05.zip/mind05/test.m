function y=test(x)
y=10*x