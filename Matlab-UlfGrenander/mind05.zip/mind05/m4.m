function val4=m4(val4)
load c:\new val1 val2 val3
save c:\new 