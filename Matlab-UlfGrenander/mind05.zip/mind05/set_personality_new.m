function set_personality_new
load c:\mind_data
[val1,val2,val3,val4]=person


save c:\mind_data
cd \mind05
return