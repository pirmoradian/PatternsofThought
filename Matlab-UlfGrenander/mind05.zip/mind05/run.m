function run(val1)
save new val1