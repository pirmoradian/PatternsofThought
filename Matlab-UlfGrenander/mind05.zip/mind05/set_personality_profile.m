function values=set_personality_profile
%sets personality for "self"
h=gco(person)
values=get(h,'Value')
