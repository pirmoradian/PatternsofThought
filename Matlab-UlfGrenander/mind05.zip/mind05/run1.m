function run1
set_personality
save new val1
