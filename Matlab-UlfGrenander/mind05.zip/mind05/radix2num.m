function N=radix2num(gs,r)
%transforms radix representatiom (...ge(3),gs(2),gs(1)) to Godel number
p=length(gs);
N=(r.^(p-1:-1:0))*gs;
