function set_personality
personality1
waitforbuttonpress
personality2
waitforbuttonpress
personality3
waitforbuttonpress
personality4
waitforbuttonpress
close all
cd \mind05
return