function val3=m3(val3)
load c:\new val1 val2
save c:\new 