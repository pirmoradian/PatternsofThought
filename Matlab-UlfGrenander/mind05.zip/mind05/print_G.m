function print_G(G,modalities)
%prints generator space
r=length(G);
for g=1:r
   disp([num2str(g),' = ',G(g).name,', level= ',num2str(G(g).level),', = modality= ',...
       modalities(G(g).modality,:),num2str(G(g).modality)])
   end