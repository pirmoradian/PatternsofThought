  #include "matlib.h"
  #pragma hdrstop
  
  #include "mind05.h"
  
  
  int main() {
    begin_scope
    
    initM(MATCOM_VERSION);
    
    #include "mind05.cpp"
    
    exitM();
    return 0;
    end_scope
  }
  
  
  
