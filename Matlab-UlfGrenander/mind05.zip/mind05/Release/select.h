#ifndef __select_h
#define __select_h

Mm select(Mm probs);

#endif // __select_h
