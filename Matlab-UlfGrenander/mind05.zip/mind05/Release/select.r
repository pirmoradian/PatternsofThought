C:\mind05\select.m
[undefined]
[called]
select function 1 1 0 1 0 0 0 0 0 0 0 
[input]
probs double 0 0 0 0 0 0 0 0 0 0 0 
[output]
number double 0 0 0 0 0 0 0 0 0 0 0 
[feval]
[callbacks]
[extern]
[declare]
number double 0 0 0 0 0 0 0 0 0 0 0 
r double 0 0 0 0 0 0 0 0 0 0 0 
