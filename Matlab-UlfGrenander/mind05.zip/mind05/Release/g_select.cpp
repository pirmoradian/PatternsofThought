  #include "matlib.h"
  #pragma hdrstop
  
  #include "select.h"
  
  
  int main(int argc, char** argv) {
    begin_scope
    
    initM(MATCOM_VERSION);
    
    if (argc<1) error("no argument supplied");
    select(TM(argv[1]));
    
    exitM();
    return 0;
    end_scope
  }
  
  
  
