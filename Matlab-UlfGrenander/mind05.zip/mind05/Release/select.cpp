  #include "matlib.h"
  #pragma hdrstop
  
  #include "select.h"
  
  
  Mm select(Mm probs) {
    begin_scope
    probs.setname("probs"); 
    dMm(number); dMm(r); 
    
    call_stack_begin;
    // nargin, nargout entry code
    double old_nargin=nargin_val; if (!nargin_set) nargin_val=1.0;
    nargin_set=0;
    double old_nargout=nargout_val; if (!nargout_set) nargout_val=1.0;
    nargout_set=0;
    
    // translated code
    
    //selects at random integer from 1 to length(probs) with probabilities in "probs"
    r = length(probs);
    number = 1.0+sum(rand(1.0)>cumsum(probs));
    
    call_stack_end;
    
    // nargin, nargout exit code
    nargin_val=old_nargin; nargout_val=old_nargout;
    
    // function exit code
    probs.setname(NULL); 
    return number;
    end_scope
  }
  
  
