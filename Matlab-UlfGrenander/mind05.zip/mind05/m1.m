function val1=m1(val1)
load c:\new
save c:\new 