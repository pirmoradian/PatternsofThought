function set_personality1
global val
h=personality1

