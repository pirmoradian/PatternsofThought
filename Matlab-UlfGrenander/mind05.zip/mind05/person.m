function [val1 val2 val3 val4]=person
val1=.2*menu('Degree of Greedy', 'Low','Fairly Low','Medium','Fairly Hight','High')
val2=.2*menu('Degree of Scholastic', 'Low','Fairly Low','Medium','Fairly Hight','High')
val3=.2*menu('Degree of Aggressive', 'Low','Fairly Low','Medium','Fairly Hight','High')
val4=.2*menu('Degree of Selfish', 'Low','Fairly Low','Medium','Fairly Hight','High')